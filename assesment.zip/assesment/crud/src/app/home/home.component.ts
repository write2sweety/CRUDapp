﻿import {
    Component,
    OnInit
} from '@angular/core';
import {
    HttpClient,
    HttpHeaders
} from '@angular/common/http';
import {
    EmployeeService, AuthenticationService
} from '../_services';
import {
    Observable
} from 'rxjs';

@Component({
    templateUrl: 'home.component.html',
    styleUrls: ['home.component.css']
})
export class HomeComponent implements OnInit {
    loggedUser;
    employeeData;
    readData: boolean = true;
    addData: boolean = false;
    editData: boolean = false;
    editId: number;

    constructor(private employeeService: EmployeeService, private authenticationService: AuthenticationService) {
        this.loggedUser = localStorage.getItem('user');
     }
        
    


    ngOnInit() {
        this.fetchData();
        
        

    }
    fetchData = function() {
        this.employeeService.getEmployeeData()
            .subscribe(data => {
                this.employeeData = data;
                
            });
    }
    delete(id) {
        if (confirm("Are you sure you want to delete it?")) {
            this.employeeService.deleteEmployeeData(id)
                .toPromise().then(() => {
                    this.fetchData();
                });

        }
    }
    add(event) {
        this.readData = false;
        this.addData = true;
        this.editData = false;

    }
    edit(id) {
        this.readData = false;
        this.addData = false;
        this.editData = true;
        this.editId = id;

    }
    back(event) {
        this.readData = true;
        this.addData = false;
        this.editData = false;
        this.fetchData();


    }


}