import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  constructor(private http: HttpClient) { }
  employeeDetailUrl = 'http://localhost:5555/employee';
  employeeRegisterUrl = 'http://localhost:4444/registerEmployee';
  id: number;
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  getEmployeeData() {
    return this.http.get(this.employeeDetailUrl).pipe(map(res => res));
  }
  postEmployeeData(postEmployee) {
    return this.http.post(this.employeeDetailUrl, postEmployee).pipe(map(res => res));
  }
  deleteEmployeeData(deleteEmployeeData) {

    return this.http.delete(this.employeeDetailUrl + '/' + deleteEmployeeData, { headers: this.headers }).pipe(map(res => res));
  }
  postRegisterEmployeeData(registerData) {
    return this.http.post(this.employeeRegisterUrl, registerData).pipe(map(res => res));
  }
  updateRegisterEmployeeData(id, updatedEmployeeForm){return this.http.put(this.employeeDetailUrl +'/' + id, updatedEmployeeForm,  { headers: this.headers }).pipe(map(res => res));
  }

}
