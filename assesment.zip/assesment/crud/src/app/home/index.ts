﻿export * from './home.component';
export * from './add-data/add-data.component';