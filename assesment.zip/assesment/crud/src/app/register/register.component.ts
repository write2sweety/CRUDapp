﻿import {
    Component,
    OnInit
} from '@angular/core';
import {
    Router
} from '@angular/router';
import {
    FormBuilder,
    FormGroup,
    Validators
} from '@angular/forms';
import {
    EmployeeService
} from '../_services';



@Component({
    templateUrl: 'register.component.html'
})
export class RegisterComponent implements OnInit {
    registerForm: FormGroup;
    submitted = false;
    registerEmployeeData;
    successMessage: boolean = false;

    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private employeeService: EmployeeService) {}

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            username: ['', Validators.required],
            password: ['', [Validators.required, Validators.minLength(6)]]
        });
    }


    get registerFormData() {
        return this.registerForm.controls;
    }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;

        }
        this.successMessage = true;
        this.employeeService.postRegisterEmployeeData(this.registerForm.value)
            .subscribe(data => {
                this.registerEmployeeData = data;
            });
        this.registerForm.reset();
              this.registerForm.markAsUntouched();
             Object.keys(this.registerForm.controls).forEach((name) => {
             let control = this.registerForm.controls[name];
             control.setErrors(null);
             return false;
    });




    }
}