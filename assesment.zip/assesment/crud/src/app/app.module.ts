import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule }    from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { routing }        from './app.routing';
import { AuthenticationService, EmployeeService } from './_services';
import { AuthGuard } from './_guards';

import { AppComponent } from './app.component';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';
import { AddDataComponent } from './home/add-data/add-data.component';
import { EditDataComponent } from './home/edit-data/edit-data.component'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AddDataComponent,
    EditDataComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    routing
  ],
  providers: [
    AuthenticationService,
    EmployeeService,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
