import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {
  EmployeeService
} from '../../_services';

@Component({
  selector: 'app-add-data',
  templateUrl: './add-data.component.html',
  styleUrls: ['./add-data.component.css']
})
export class AddDataComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  successMessage: boolean = false;


  constructor(private formBuilder: FormBuilder, private http: HttpClient, private employeeService: EmployeeService) { }

  ngOnInit() {
    this.formStatus();

  }
  formStatus = function () {
    this.employeeForm = this.formBuilder.group({
      name: ['', Validators.required],
      skill: ['', Validators.required],
      profile: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],

    });
  }
  get employee() { return this.employeeForm.controls; }
  addEmployee() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.employeeForm.invalid) {
      return;
    }

    this.successMessage = true;
    this.employeeService.postEmployeeData(this.employeeForm.value)
      .subscribe(data => {

      });
    this.employeeForm.reset();
    this.employeeForm.markAsUntouched();
    Object.keys(this.employeeForm.controls).forEach((name) => {
      let control = this.employeeForm.controls[name];
      control.setErrors(null);
      return false;
    });

  }


}

