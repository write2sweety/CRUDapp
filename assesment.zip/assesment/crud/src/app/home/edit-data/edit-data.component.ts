import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators, Form } from '@angular/forms';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {
  EmployeeService
} from '../../_services';
//import { Observable} from 'rxjs';

@Component({
  selector: 'app-edit-data',
  templateUrl: './edit-data.component.html',
  styleUrls: ['./edit-data.component.css']
})
export class EditDataComponent implements OnInit {
  employeeForm: FormGroup;
  submitted = false;
  successMessage: boolean = false;
  employeeData;
  @Input() id: number;
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  url;





  constructor(private formBuilder: FormBuilder, private http: HttpClient, private employeeService: EmployeeService) { }

  ngOnInit() {

    this.fetchData();
    this.formStatus();
    this.url = 'http://localhost:5555/employee' + '/' + this.id;


  }

  fetchData = function () {
    this.employeeService.getEmployeeData()
      .subscribe(data => {
        this.employeeData = data;
        for (let i = 0; i <= this.employeeData.length; i++) {
          if (this.employeeData[i].id === this.id) {
            this.employeeForm.name = this.employeeData[i].name;
            this.employeeForm.skill = this.employeeData[i].skill;
            this.employeeForm.profile = this.employeeData[i].profile;
            this.employeeForm.email = this.employeeData[i].email;
          }
        }
      });
  }
  formStatus = function () {
    this.employeeForm = this.formBuilder.group({
      name: ['', Validators.required],
      skill: ['', Validators.required],
      profile: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],

    });
  }
  get updateEmployee() { return this.employeeForm.controls; }

  updateEmployeeDetail() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.employeeForm.invalid) {
      return;
    }

    this.employeeService.updateRegisterEmployeeData(this.id, this.employeeForm.value)
      .toPromise().then(() => {
        this.successMessage = true;
        this.employeeForm.reset();
        this.employeeForm.markAsUntouched();
        Object.keys(this.employeeForm.controls).forEach((name) => {
          let control = this.employeeForm.controls[name];
          control.setErrors(null);
        });
      });





  }


}
